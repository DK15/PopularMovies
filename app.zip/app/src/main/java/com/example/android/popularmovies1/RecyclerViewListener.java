package com.example.android.popularmovies1;

interface RecyclerViewListener {

    void itemClick(int pos);
}
